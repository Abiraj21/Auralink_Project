# services/quote_service.py

import random
from openai import OpenAI
from datetime import datetime
import traceback
from config.settings import OPENAI_API_KEY

class QuoteService:
    def __init__(self, mongo_service):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.mongo = mongo_service
    
    def generate_optimized_quote(self, temp, humidity):
        """Generate SHORT quotes optimized for small OLED display"""
        
        # Time-based context
        current_hour = datetime.now().hour
        if 5 <= current_hour < 12:
            time_context = "morning"
        elif 12 <= current_hour < 17:
            time_context = "afternoon" 
        elif 17 <= current_hour < 22:
            time_context = "evening"
        else:
            time_context = "night"
        
        # Weather context
        if temp > 28:
            weather_context = "warm"
        elif temp < 18:
            weather_context = "cool"
        else:
            weather_context = "comfortable"
            
        if humidity > 70:
            air_context = "humid"
        elif humidity < 40:
            air_context = "dry"
        else:
            air_context = "pleasant"
        
        # SHORT prompts for small display
        prompts = [
            f"Create a VERY short inspiring quote (max 8 words) for {time_context} study in {weather_context} weather.",
            f"Write a brief motivational thought (max 10 words) for {time_context} productivity.",
            f"Generate a concise uplifting message (max 8 words) for {weather_context} {time_context} work.",
            f"Short inspiring quote (max 2 lines) for {time_context} in {air_context} air.",
        ]
        
        prompt = random.choice(prompts)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You generate very short, concise quotes (maximum 60 characters, 2 lines). Perfect for small OLED displays."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=30,
                temperature=0.8
            )
            
            # FIX: Handle None response safely
            quote = response.choices[0].message.content
            if quote is not None:
                quote = quote.strip()
            else:
                quote = "Stay focused and productive."
            
            # Ensure quote is short enough
            if len(quote) > 60:
                words = quote.split()
                short_quote = ""
                for word in words:
                    if len(short_quote + word) < 55:
                        short_quote += word + " "
                    else:
                        break
                quote = short_quote.strip() + "..."
            
            return quote
            
        except Exception as e:
            self.mongo.log_error("OpenAIError", str(e), traceback.format_exc(), {"function": "generate_optimized_quote"})
            
            # Ultra-short fallback quotes
            short_fallback = [
                "Stay focused and learn.",
                "Every moment brings growth.",
                "Knowledge is your power.",
                "Progress happens step by step.",
                "Your environment shapes success.",
                "Embrace the learning journey.",
                "Small steps, big achievements.",
                "Focus and persistence win.",
            ]
            return random.choice(short_fallback)