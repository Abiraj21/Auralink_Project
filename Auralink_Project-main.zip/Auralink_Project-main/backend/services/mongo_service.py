# services/mongo_service.py

from pymongo import MongoClient
from datetime import datetime
import traceback
from config.settings import MONGODB_URI, DATABASE_NAME, COLLECTION_NAMES

class AuraLinkMongoDB:
    def __init__(self):
        self.client = None
        self.db = None
        self.collections = {}
        self.is_connected = False
        self.connect()
    
    def connect(self):
        """Establish MongoDB connection with better error handling"""
        try:
            self.client = MongoClient(
                MONGODB_URI, 
                serverSelectionTimeoutMS=10000,
                connectTimeoutMS=10000,
                socketTimeoutMS=10000
            )
            server_info = self.client.server_info()
            self.db = self.client[DATABASE_NAME]
            
            for key, collection_name in COLLECTION_NAMES.items():
                self.collections[key] = self.db[collection_name]
                self.collections[key].create_index("timestamp")
            
            self.is_connected = True
            return True
            
        except Exception as e:
            self.is_connected = False
            return False
    
    def log_sensor_data(self, temp, humidity, quote, email_summary, priority):
        """Log sensor data and system response"""
        if not self.is_connected:
            return False
            
        try:
            document = {
                "timestamp": datetime.now(),
                "temperature": temp,
                "humidity": humidity,
                "quote": quote,
                "email_summary": email_summary,
                "priority_level": priority,
                "sensor_read_time": datetime.now()
            }
            
            result = self.collections["sensor_data"].insert_one(document)
            return True
            
        except Exception as e:
            return False
    
    def log_email_event(self, email_summary, priority, urgent_count, total_count, email_updated):
        """Log email checking events"""
        if not self.is_connected:
            return False
            
        try:
            document = {
                "timestamp": datetime.now(),
                "email_summary": email_summary,
                "priority_level": priority,
                "urgent_email_count": urgent_count,
                "total_unread_count": total_count,
                "fresh_scan": email_updated,
                "event_type": "email_check"
            }
            
            result = self.collections["email_events"].insert_one(document)
            return True
            
        except Exception as e:
            return False
    
    def log_quote_event(self, quote, temp, humidity, trigger_reason):
        """Log quote generation events"""
        if not self.is_connected:
            return False
            
        try:
            document = {
                "timestamp": datetime.now(),
                "quote": quote,
                "temperature": temp,
                "humidity": humidity,
                "trigger_reason": trigger_reason,
                "event_type": "quote_generation"
            }
            
            result = self.collections["quote_events"].insert_one(document)
            return True
            
        except Exception as e:
            return False
    
    def log_system_event(self, event_type, message, details=None):
        """Log system events"""
        if not self.is_connected:
            return False
            
        try:
            document = {
                "timestamp": datetime.now(),
                "event_type": event_type,
                "message": message,
                "details": details or {},
                "system_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            result = self.collections["system_events"].insert_one(document)
            return True
            
        except Exception as e:
            return False
    
    def log_error(self, error_type, error_message, traceback_info=None, context=None):
        """Log error events with context"""
        if not self.is_connected:
            return False
            
        try:
            document = {
                "timestamp": datetime.now(),
                "error_type": error_type,
                "error_message": error_message,
                "traceback": traceback_info,
                "context": context or {},
                "severity": "error",
                "system_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            result = self.collections["error_logs"].insert_one(document)
            return True
            
        except Exception as e:
            return False