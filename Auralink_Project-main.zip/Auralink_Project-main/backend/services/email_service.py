# services/email_service.py

import imaplib
import email
from email.header import decode_header
from datetime import datetime, timedelta
import traceback
from config.settings import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT

class EmailService:
    def __init__(self, state_manager, mongo_service):
        self.state = state_manager
        self.mongo = mongo_service
    
    def is_urgent_email(self, subject, sender):
        """Detect if an email is urgent based ONLY on subject and sender patterns"""
        subject_lower = subject.lower()
        sender_lower = sender.lower()
        
        urgent_keywords = [
            'urgent', 'asap', 'important', 'emergency', 'critical', 
            'action required', 'immediate', 'deadline', 'today',
            'breaking', 'alert', 'attention', 'priority'
        ]
        
        important_senders = [
            'boss', 'manager', 'supervisor', 'client', 'hr@', 'admin@',
            'noreply', 'notification', 'security', 'support', 'teamlead'
        ]
        
        subject_urgent = any(keyword in subject_lower for keyword in urgent_keywords)
        sender_important = any(sender_keyword in sender_lower for sender_keyword in important_senders)
        
        return subject_urgent or sender_important

    def shorten_subject(self, subject, max_length=25):
        """Shorten email subject for display on small OLED"""
        if len(subject) <= max_length:
            return subject
        return subject[:max_length-3] + "..."

    def _decode_header_value(self, header_value):
        """Safely decode email header values"""
        if header_value is None:
            return ""
        
        try:
            decoded_parts = decode_header(header_value)
            decoded_string = ""
            
            for part, encoding in decoded_parts:
                if isinstance(part, bytes):
                    if encoding:
                        decoded_string += part.decode(encoding, errors='ignore')
                    else:
                        decoded_string += part.decode('utf-8', errors='ignore')
                else:
                    decoded_string += str(part)
            
            return decoded_string.strip()
        except Exception as e:
            return str(header_value) if header_value else ""

    def get_email_headers_only(self):
        """
        Get email information WITHOUT reading content - only headers
        Returns: email_summary, priority, should_update, urgent_count, total_count
        """
        if not self.state.should_check_email():
            return (self.state.current_email_summary, self.state.current_priority, 
                    False, len(self.state.urgent_emails), self.state.total_unread_count)
    
        try:
            # Connect to Gmail
            mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
            mail.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            mail.select("inbox")
            
            # Search for UNREAD emails from LAST 24 HOURS only
            since_date = (datetime.now() - timedelta(hours=24)).strftime("%d-%b-%Y")
            search_criteria = f'(UNSEEN SINCE "{since_date}")'
            
            status, email_ids = mail.search(None, search_criteria)
            
            urgent_emails = []
            total_unread_count = 0
            
            if status == "OK" and email_ids[0]:
                email_id_list = email_ids[0].split()
                total_unread_count = len(email_id_list)
                
                # Check only email headers, not content
                for email_id in email_id_list:
                    status, header_data = mail.fetch(email_id, '(BODY.PEEK[HEADER])')
                    
                    if status == "OK" and header_data[0]:
                        try:
                            header_text = header_data[0][1].decode('utf-8', errors='ignore')
                            email_headers = email.message_from_string(header_text)
                            
                            # Extract subject using safe decoding
                            subject = self._decode_header_value(email_headers.get('subject', ''))
                            if not subject:
                                subject = "No Subject"
                            
                            # Extract sender using safe decoding
                            sender = self._decode_header_value(email_headers.get('from', ''))
                            if not sender:
                                sender = "Unknown"
                            
                            # Check if urgent based on headers only
                            if self.is_urgent_email(subject, sender):
                                short_subject = self.shorten_subject(subject)
                                urgent_emails.append(short_subject)
                                
                                if len(urgent_emails) >= 5:
                                    break
                        except Exception as e:
                            # Skip this email if there's an error processing headers
                            continue
            
            # Update state with urgent emails and count
            self.state.urgent_emails = urgent_emails
            self.state.total_unread_count = total_unread_count
            self.state.email_display_index = 0
            
            # Generate appropriate summary message
            urgent_count = len(urgent_emails)
            
            if urgent_count > 0:
                if urgent_count == 1:
                    email_summary = f"URGENT: {urgent_emails[0]}"
                    priority = "high"
                else:
                    next_subject = self.state.get_next_urgent_email_display()
                    email_summary = f"{urgent_count} URGENT - {next_subject}" if next_subject else f"{urgent_count} URGENT emails"
                    priority = "high"
            else:
                if total_unread_count == 0:
                    email_summary = "No new emails"
                    priority = "low"
                elif total_unread_count == 1:
                    email_summary = "1 new email"
                    priority = "normal"
                else:
                    email_summary = f"{total_unread_count} new emails"
                    priority = "normal"
            
            mail.close()
            mail.logout()
            
            # Update state
            self.state.current_email_summary = email_summary
            self.state.current_priority = priority
            self.state.last_email_check = datetime.now()
            
            # Log to MongoDB
            self.mongo.log_email_event(email_summary, priority, urgent_count, total_unread_count, True)
            
            return email_summary, priority, True, urgent_count, total_unread_count
            
        except Exception as e:
            self.mongo.log_error("GmailError", str(e), traceback.format_exc(), {"function": "get_email_headers_only"})
            return "Email connection failed", "low", False, 0, 0