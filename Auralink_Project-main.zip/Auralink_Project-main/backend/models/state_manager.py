# models/state_manager.py

from datetime import datetime

class AuraLinkState:
    def __init__(self):
        self.last_quote_time = None
        self.current_quote = "Welcome to AuraLink"
        self.last_email_check = None
        self.current_email_summary = "Checking emails..."
        self.current_priority = "normal"
        self.last_temperature = 22.0
        self.last_humidity = 50.0
        self.urgent_emails = []
        self.total_unread_count = 0
        self.email_display_index = 0
        
    def should_generate_new_quote(self, current_temp, current_humidity, temp_threshold=5, humidity_threshold=20):
        """Check if we should generate a new quote"""
        if self.last_quote_time is None:
            return True, "first_quote"
            
        time_since_last_quote = datetime.now() - self.last_quote_time
        temp_change = abs(current_temp - self.last_temperature)
        humidity_change = abs(current_humidity - self.last_humidity)
        
        if time_since_last_quote.total_seconds() >= 3600:
            self.last_temperature = current_temp
            self.last_humidity = current_humidity
            return True, "time_trigger"
        elif temp_change > temp_threshold:
            self.last_temperature = current_temp
            self.last_humidity = current_humidity
            return True, "temperature_change"
        elif humidity_change > humidity_threshold:
            self.last_temperature = current_temp
            self.last_humidity = current_humidity
            return True, "humidity_change"
            
        return False, "no_change"
        
    def should_check_email(self, check_interval=5):
        """Check if we should check email again"""
        if self.last_email_check is None:
            return True
            
        time_since_last_check = datetime.now() - self.last_email_check
        return time_since_last_check.total_seconds() >= check_interval

    def get_next_urgent_email_display(self):
        """Get the next urgent email to display"""
        if not self.urgent_emails:
            return None
            
        email_subject = self.urgent_emails[self.email_display_index]
        self.email_display_index = (self.email_display_index + 1) % len(self.urgent_emails)
        return email_subject