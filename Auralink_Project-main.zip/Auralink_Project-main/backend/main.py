# main.py

import json
import paho.mqtt.client as mqtt
import traceback
from datetime import datetime

# Import from modular structure
from config.settings import BROKER, PORT, TOPIC_SUB, TOPIC_PUB
from utils.logger import setup_logging
from models.state_manager import AuraLinkState
from services.mongo_service import AuraLinkMongoDB
from services.email_service import EmailService
from services.quote_service import QuoteService

# Initialize components
logger = setup_logging()
state = AuraLinkState()
mongo_client = AuraLinkMongoDB()
email_service = EmailService(state, mongo_client)
quote_service = QuoteService(mongo_client)

def on_connect(client, userdata, flags, rc):
    connection_msg = "Connected to MQTT Broker"
    logger.info(connection_msg)
    
    mongo_client.log_system_event("mqtt_connection", connection_msg, {"broker": BROKER, "port": PORT})
    
    client.subscribe(TOPIC_SUB)
    logger.info("Listening for sensor data...")
    logger.info("Backend running in NOTIFICATION-ONLY mode")
    logger.info("   • Quotes: 1 hour or major changes")
    logger.info("   • Emails: Header-only check every 5 seconds")
    logger.info("   • NO EMAIL CONTENT READING - Privacy protected")
    logger.info("   • Urgent detection via subject/sender patterns only")

def on_message(client, userdata, msg):
    logger.info("Received sensor data from ESP32")
    
    try:
        data = json.loads(msg.payload.decode())
        temp = data.get("temp", 22.0)
        humidity = data.get("humidity", 50.0)
        
        logger.info(f"Current: {temp}C, {humidity}% humidity")
        
        # Smart quote generation - only when needed
        should_generate, trigger_reason = state.should_generate_new_quote(temp, humidity)
        if should_generate:
            logger.info(f"Generating new quote (trigger: {trigger_reason})")
            quote = quote_service.generate_optimized_quote(temp, humidity)
            state.current_quote = quote
            state.last_quote_time = datetime.now()
            
            mongo_client.log_quote_event(quote, temp, humidity, trigger_reason)
        else:
            logger.info("Using cached quote")
            quote = state.current_quote
        
        # Email checking with headers only - NO CONTENT READING
        email_summary, priority, email_updated, urgent_count, total_count = email_service.get_email_headers_only()
        
        # Prepare response
        payload = {
            "quote": quote,
            "email": email_summary,
            "priority": priority,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "quote_updated": state.last_quote_time.strftime("%H:%M") if state.last_quote_time else "Never",
            "email_updated": state.last_email_check.strftime("%H:%M:%S") if state.last_email_check else "Never",
            "urgent_count": urgent_count,
            "total_unread": total_count,
            "urgent_subjects": state.urgent_emails,
            "display_index": state.email_display_index
        }

        # Send to ESP32
        client.publish(TOPIC_PUB, json.dumps(payload))
        
        # Log sensor data
        mongo_client.log_sensor_data(temp, humidity, quote, email_summary, priority)
        
        logger.info("Sent NOTIFICATION-ONLY response:")
        logger.info(f"   Quote: {quote}")
        logger.info(f"   Email: {email_summary}")
        logger.info(f"   Priority: {priority}")
        logger.info(f"   Urgent: {urgent_count}, Total: {total_count}")
        if email_updated:
            logger.info("   Fresh header-only email scan")
        else:
            logger.info("   Cached email data")
        
    except Exception as e:
        error_msg = f"Error processing MQTT message: {e}"
        logger.error(error_msg)
        mongo_client.log_error("MQTTMessageError", str(e), traceback.format_exc(), {"topic": TOPIC_SUB})

if __name__ == "__main__":
    startup_msg = "AuraLink NOTIFICATION-ONLY Backend Starting..."
    logger.info(startup_msg)
    
    mongo_client.log_system_event("system_startup", startup_msg)
    
    logger.info("Using: rkkishor21012@gmail.com")
    logger.info("PRIVACY PROTECTED MODE:")
    logger.info("   • Header-only email scanning")
    logger.info("   • NO email content reading") 
    logger.info("   • Urgent detection via subject/sender patterns")
    logger.info("   • Smart quote refresh (1h/major changes)")
    logger.info("   • Real-time email counting every 5 seconds")
    
    if mongo_client.is_connected:
        logger.info("   • MongoDB logging: ENABLED and CONNECTED")
    else:
        logger.warning("   • MongoDB logging: DISABLED - Check connection")
    
    client_mqtt = mqtt.Client()
    client_mqtt.on_connect = on_connect
    client_mqtt.on_message = on_message
    
    try:
        client_mqtt.connect(BROKER, PORT, 60)
        logger.info("Backend running successfully!")
        logger.info("   Press Ctrl+C to stop")
        
        mongo_client.log_system_event("mqtt_connected", "Successfully connected to MQTT broker")
        
        client_mqtt.loop_forever()
    except KeyboardInterrupt:
        shutdown_msg = "Server stopped by user"
        logger.info(shutdown_msg)
        mongo_client.log_system_event("system_shutdown", shutdown_msg)
    except Exception as e:
        error_msg = f"Connection failed: {e}"
        logger.error(error_msg)
        mongo_client.log_error("ConnectionError", str(e), traceback.format_exc(), {"broker": BROKER, "port": PORT})