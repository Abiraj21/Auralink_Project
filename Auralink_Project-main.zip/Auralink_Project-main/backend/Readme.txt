==============================
AURALINK - BACKEND SETUP GUIDE
==============================

Project: Personal Productivity Hub (AuraLink)
Language: Python
Environment: Visual Studio Code
Python Version: 3.13.x

---------------------------------------------
Overview
---------------------------------------------
The AuraLink backend handles:
- Receiving sensor data from ESP32 via MQTT.
- Generating AI-based motivational quotes using OpenAI API.
- Summarizing emails (via Gmail API - optional).
- Sending messages (quotes + summaries + urgency) back to the IoT device.

---------------------------------------------
Required Python Libraries
---------------------------------------------
In VS Code terminal, install the following:

pip install paho-mqtt openai

Optional libraries for email integration:

pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib

---------------------------------------------
MQTT Broker Configuration
---------------------------------------------
Default settings in code:
BROKER = "broker.hivemq.com"
PORT = 1883
TOPIC_SUB = "productivityhub/sensor"
TOPIC_PUB = "productivityhub/message"

You can replace these with your own MQTT broker settings if needed.

---------------------------------------------
How to Run the Backend
---------------------------------------------
1. Run in new terminal 1:
   python auralink_backend.py
2. Run in new terminal 2:
   python virtual_tester.py

You should see in backend:
🔌 Connecting to MQTT broker...
✅ Connected to MQTT Broker.

You should see in virtual tester:
🚀 Starting virtual test...
This will send 3 test sensor readings to your backend
Waiting 2 seconds for connections...

📤 Sending test data 1: {'temp': 22.5, 'humidity': 65}

When sensor data is published to "productivityhub/sensor",
the backend will:
- Generate an AI quote.
- Simulate or summarize email data.
- Send back a response via "productivityhub/message".

---------------------------------------------
Example Output
---------------------------------------------
📩 Received from ESP32: {"temp": 28.3, "humidity": 55.7"}
📤 Sent to ESP32: {'quote': 'Stay calm and focused under pressure.',
                   'email': 'Urgent Email: Meeting Reminder',
                   'priority': 'high'}


---------------------------------------------
Next Steps
---------------------------------------------
- Integrate Gmail API for real email summaries.
- Add temperature trend prediction or voice feedback.
- Test with simulated ESP32 using Python or Wokwi.

