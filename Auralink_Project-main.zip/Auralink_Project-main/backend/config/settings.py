# config/settings.py

# MongoDB Configuration
MONGODB_URI = ""
DATABASE_NAME = ""

COLLECTION_NAMES = {
    "sensor_data": "sensor_data",
    "email_events": "email_events", 
    "quote_events": "quote_events",
    "system_events": "system_events",
    "error_logs": "error_logs"
}

# MQTT Configuration
BROKER = "broker.hivemq.com"
PORT = 1883
TOPIC_SUB = "productivityhub/sensor"
TOPIC_PUB = "productivityhub/message"

# OpenAI Configuration
OPENAI_API_KEY = ""

# Gmail Configuration
EMAIL_ADDRESS = ""
EMAIL_PASSWORD = ""
IMAP_SERVER = "imap.gmail.com"
IMAP_PORT = 993

# Application Settings
EMAIL_CHECK_INTERVAL = 5  # seconds
QUOTE_GENERATION_INTERVAL = 3600  # 1 hour in seconds
TEMP_CHANGE_THRESHOLD = 5  # °C
HUMIDITY_CHANGE_THRESHOLD = 20  # %