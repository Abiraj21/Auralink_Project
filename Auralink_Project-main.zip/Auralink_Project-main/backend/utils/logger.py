# utils/logger.py

import logging
import sys
from logging.handlers import TimedRotatingFileHandler

def setup_logging():
    """Setup comprehensive logging with file rotation"""
    logger = logging.getLogger('AuraLink')
    logger.setLevel(logging.INFO)
    
    # Clear any existing handlers
    logger.handlers.clear()
    
    # Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    # File Handler with rotation (daily rotation, keep 7 days)
    file_handler = TimedRotatingFileHandler(
        'auralink.log', 
        when='D', 
        interval=1, 
        backupCount=7
    )
    file_handler.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger