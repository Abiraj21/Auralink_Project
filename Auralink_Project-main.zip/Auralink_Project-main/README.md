# Auralink_Project
🧠 AuraLink – Personal Productivity Hub  AuraLink is an AI-powered IoT productivity assistant designed to help users stay focused, informed, and motivated throughout their day. It combines smart sensors, real-time communication, and AI features into a compact desktop device that improves the working experience. 
